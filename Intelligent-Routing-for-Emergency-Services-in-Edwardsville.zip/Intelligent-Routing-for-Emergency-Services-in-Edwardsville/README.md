# Intelligent Routing for Emergency Services in Edwardsville ![image](https://github.com/sushrit7/Intelligent-Routing-for-Emergency-Services-in-Edwardsville/assets/69793434/0c4ccbb3-40af-499c-8164-da021cc3f587)


### Clone the Repository

```bash
git clone https://github.com/sushrit7/Intelligent-Routing-for-Emergency-Services-in-Edwardsville
```

### Usage
```bash
python3 main.py 
```

### Experiment
there are experiment 1, 2 and 3. run it and get the results.
